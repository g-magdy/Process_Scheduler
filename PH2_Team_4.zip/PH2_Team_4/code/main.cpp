
#include"Scheduler.h"

int main()
{

	Scheduler ProScheduler;

	ProScheduler.startUp();
	
	//ProScheduler.simulation();

	ProScheduler.run();

	return 0;
}
